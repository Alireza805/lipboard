<?php
include 'ip2.php';
header('Location: forwarding_link/index1.html');
exit
?>
